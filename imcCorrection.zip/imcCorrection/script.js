/*
Disclaimer :
----------
Cette correction n'est pas un modèle de ce qu'il fallait faire, mais plutôt un panel 
de méthodes que vous pouviez utiliser pour répondre à la consigne donnée.
C'est pourquoi le fichier n'est pas homogène avec des choix différents suivant les parties
et vous présente différentes solutions pour répondre à la consigne de l'exercice.
Vous pouviez tout à fait faire beaucoup plus court pour le HTML, le CSS et le javaScript !
*/


// DECLARATIONS DES VARIABLES ET DES CONSTANTES //

/*
Remarque : 
--------
Une variable déclarée avec const ne peut pas être réaffectée, en rechanche on peut
tout à fait en changer les propriétés. Même si ce n'est pas nécessairement recommendé 
de modifier des "constantes" !
Plus d'infos : https://developer.mozilla.org/fr/docs/Web/JavaScript/Reference/Statements/const
*/

const LOGO = document.getElementById("logo");


// DECLARATION DES FONCTIONS //
function change_image(){
	/* Change d'image à chaque survol de la souris */

	/* 
	LOGO.src renvoie le chemin absolu du fichier
	LOGO.getAttribute("src") renvoie  le contenu de l'attribut html, ici 
	son chemin relatif
	*/
	if (LOGO.getAttribute("src") == "./images/slim.png"){
		LOGO.setAttribute("src", "./images/big.png");
	}
	else {
		// Autre possibilité pour modifier la source
		LOGO.src = "./images/slim.png";
	}
}

function age(){
	/* Vérification du formulaire à l'aide de checkValidity (intégré au html5 et js)
	Ici les "tests" de validité sont automatiques, j'ai rajouté des "info bulle" pour 
	spécifier quelles étaient les parties du formulaire à compléter différemment.
	Les messages des "infos-bulles" sont complétées automatiquement en fonction de la 
	langue du navigateur
	*/

	// Définition des variables utilisées
	let answer = document.getElementById('ans');
	let prenom = document.getElementById('prenom');
	let info_prenom = document.getElementById('info_prenom');
	let annee = document.getElementById('an');
	let info_annee = document.getElementById('info_annee');

	// Remise à zéro des messages (info bulle et répnse finale) et des styles
	info_annee.innerHTML = "";
	info_annee.style.display = "none";
	annee.className = "";

	info_prenom.innerHTML = "";
	info_prenom.style.display = "none";
	prenom.className = "";

	answer.textContent = "";
	
	// Vérification du formulaire
	if ( prenom.checkValidity() && annee.checkValidity() ){
		// On récupère l'année en cours directement avec javaScript !
		answer.textContent = new Date().getFullYear() - annee.value;	
	} else {
		/* 
		On rajoute une bulle d'info sur ce qui ne va pas
		Cette partie aurait pu être réalisée par une fonction externe
		Si l'âge n'est pas correct
		*/
		if (!annee.checkValidity()){
			info_annee.textContent = annee.validationMessage;
			info_annee.style.display = "inline-block";
			annee.focus();
			annee.className = "aCompleter";
		}
		// Si le prénom n'est pas rempli
		if (!prenom.checkValidity()){
			info_prenom.textContent = prenom.validationMessage;
			info_prenom.style.display = "inline-block";
			prenom.focus();
			prenom.className = "aCompleter";
		}

	}
}


function IMC(){
	/*
	Modifie la page en fonction de la valeur de l'imc calculée par la fonction IMC.
	Ici la validation du formulaire est faite "à la main" et le message d'information
	est affiché en dessous du formulaire si besoin
	*/
	
	// Déclariation des variables
	let calc = document.getElementById("calc");
	let etat = document.getElementById("state");
	let taille = document.getElementById("t");
	let masse = document.getElementById("m");

	/*
	On convertit les saisies en entier.
	Si la conversion n'est pas possible, t et m seront du type NaN
	Si l'utilisateur rentre des nombre décimaux ils seront convertis en entier
	par troncature.
	*/
	let t = parseInt(taille.value);
	let m = parseInt(masse.value);

	// Remise à zéro des messages
	calc.textContent = "";
	etat.textContent = "";
	taille.className = "";
	masse.className = "";
	
	/* 
	La fonction ne se lance que si le formulaire est entièrement rempli.
	Si les champs de la taille et du poids ne sont pas remplis avec des nombre
	t et m seront du type NaN, ce que l'on peut tester avec la fonction isNaN(...)
	*/
	if (!isNaN(t) &&  !isNaN(m)){
		/*
		Vérification de la taille saisie et le cas échant affichage d'un message et 
		mise du focus sur la taille
		*/
		if (t < 100 || t > 250){
			etat.textContent = "La taille doit être comprise entre 100 cm et 250 cm";
			taille.focus();
			taille.className = "aCompleter";
		}
		else if (m < 20 || m > 150){
			/*  
			Maintenant que la taille est bonne, on vérifie la masse !
			*/
			etat.textContent = "La masse doit être comprise entre 20 kg et 150 kg";
			masse.focus();
			masse.className = "aCompleter";
		} else {
			/*
			Les test sont tous passés on peut calculer l'IMC et afficher un message en
			conséquence ! 
			*/
			let imc = 10000*m / (t*t);
			calc.textContent = "Votre imc est de : " + imc;
			if(imc < 18.5){
				etat.textContent = "Vous êtes en insuffisance pondérale";
				LOGO.src = "./images/squelette.png";
			} else if (imc < 25){
				etat.textContent = "Vous êtes en poids normal";
				LOGO.src = "./images/slim.png";
			}else if(25 <= imc & imc < 30){
				etat.textContent = "Vous êtes en surpoids";
				LOGO.src = "./images/big.png";
			} else {
				etat.textContent = "Vous êtes en obésité morbide";
				LOGO.src = "./images/too_big.png";
			}
		}
	} else{
		// Affichage d'un message si la taille ou le poids ne sont pas corrects
		// Il ne fallait pas le faire suivant la consigne de l'exercice !!
		if (isNaN(m)) {
			calc.innerHTML += "<br>Saisie de la masse invalide, saisir un nombre entre 20 kg et 150 kg";
			masse.focus();
			masse.className = "aCompleter";
		}
		/* 
		L'ordre des test est inversé par rapport au formulaire pour donner le focus au premier élément
		mal rempli.
		*/ 
		if (isNaN(t)){
			calc.textContent = "Saisie de la taille invalide, saisir un nombre entre 100 cm et 250 cm";
			taille.focus();
			taille.className = "aCompleter";
		}
	}
}