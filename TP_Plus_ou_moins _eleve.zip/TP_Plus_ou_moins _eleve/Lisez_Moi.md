# Consignes pour le devoir

Ce travail est un travail sur le javascript. L'objectif est de réaliser un petit jeu du _plus ou moins_ avec un visuel imposé.

Pour cela, compléter le fichier `plus_ou_moins.js` pour obtenir le rendu projeté en classe.

> __Remarques :__
> - Les fichiers `plus_ou_moins.html` et `style.css` __ne sont pas__ à modifier.
> - Seul le fichier `plus_ou_moins.js` est à modifier.
> - Les différentes images à afficher pendant le jeu sont dans le dossier `images`.
> - Dans le dossier `visuels` vous avez des images d'*exemples* de visuels à obtenir pendant la partie.
> - On pourra dans un premier temps supposer au l'utilisateur rentre bien un nombre (ne faire la validation de la saisie que si vous avez le temps !)